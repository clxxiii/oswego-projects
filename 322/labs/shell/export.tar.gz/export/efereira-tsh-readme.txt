Eli Fereira
Tsh Lab
The make file has been modified to include gdb debug symbols when compiling.

Otherwise, the file compiles and runs just as the example should.
